package com.example.tuan1

data class BangDiemThongKe(
    val tenMon: String,
    val diemTK: Double,val diemGK: Float,
    val diemCK: Float,
    val hocKy:Int
)