package com.example.tuan1

data class TKBTenMon(
    val maTKB: Int = 0,
    val maMon: String,
    val tenMon:String,
    val tietBD: Int,
    val tietKT: Int,
    val tuan:Int,
    val thu:Int
        )